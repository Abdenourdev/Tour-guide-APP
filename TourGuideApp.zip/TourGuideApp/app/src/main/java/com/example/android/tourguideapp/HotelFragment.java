package com.example.android.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class HotelFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final ArrayList<Word> words = new ArrayList<>();
        words.add(new Word(R.drawable.aurassi, R.string.hotel_el_aurassi, R.string.hotel_el_aurassi_info));
        words.add(new Word(R.drawable.hilton, R.string.hotel_hilton, R.string.hotel_hilton_info));
        words.add(new Word(R.drawable.saint_george, R.string.hotel_saint_george, R.string.hotel_saint_george_info));
        words.add(new Word(R.drawable.sheraton, R.string.hotel_sheraton, R.string.hotel_sheraton_info));
        words.add(new Word(R.drawable.sofitel, R.string.hotel_sofital, R.string.hotel_sofital_info));
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        WordAdapter adapter = new WordAdapter(getContext(), words);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
        });
        return rootView;
    }
}