package com.example.android.tourguideapp;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class WordAdapter extends ArrayAdapter<Word> {
    private final Context context;

    WordAdapter(Context context, ArrayList<Word> words) {
        super(context, 0, words);
        this.context = context;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // Get the position for this data item
        Word words = getItem(position);
        View listsitViewItem = convertView;
        // First check to make sure the existing view is being reused, otherwise we need to inflate
        if (listsitViewItem == null) {
            // If there are no more scrap views in the scrap pile to be reused, we'll just create one by inflating from the XML layout file that we used.
            listsitViewItem = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }
        ImageView mImageViewLocation = listsitViewItem.findViewById(( R.id.site_image_view ));
        if (words != null) {
            // Now populate the three views using the data from the word object
            mImageViewLocation.setImageResource(words.getImageResourceID());

            TextView mTextSiteView = listsitViewItem.findViewById(R.id.site_address_text_view);
            mTextSiteView.setText(context.getString(words.getDefaulInformation()));

            mTextSiteView = listsitViewItem.findViewById(R.id.site_name_text_view);
            mTextSiteView.setText(context.getString(words.getDefaulLocationName()));
        }
        return listsitViewItem;
    }
}