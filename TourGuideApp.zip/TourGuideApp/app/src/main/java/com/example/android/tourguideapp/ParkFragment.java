package com.example.android.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import java.util.ArrayList;

public class ParkFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Now create an ArrayList of Word objects. Each element is a Word object
        final ArrayList<Word> words = new ArrayList<>();
        words.add(new Word(R.drawable.aquatique, R.string.park_aquatique, R.string.park_aquatique_info));
        words.add(new Word(R.drawable.zoologique, R.string.park_zoologique, R.string.park_zoologique_info));
        words.add(new Word(R.drawable.attraction, R.string.park_attraction, R.string.park_attraction_info));
        words.add(new Word(R.drawable.kifan, R.string.park_kiffan, R.string.park_kiffan_info));
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        WordAdapter adapter = new WordAdapter(getContext(), words);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
        });
        return rootView;
    }
}