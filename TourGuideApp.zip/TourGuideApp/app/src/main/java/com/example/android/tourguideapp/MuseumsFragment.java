package com.example.android.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import java.util.ArrayList;

public class MuseumsFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final ArrayList<Word> words = new ArrayList<>();
        words.add(new Word(R.drawable.antiquities, R.string.museum_national_des_antiquités, R.string.museum_national_des_antiquités_info));
        words.add(new Word(R.drawable.beaux, R.string.museum_national_des_beaux_arts, R.string.museum_national_des_beaux_arts_info));
        words.add(new Word(R.drawable.parado, R.string.museum_parado, R.string.museum_parado_info));
        words.add(new Word(R.drawable.arme, R.string.museum_of_army, R.string.museum_of_army_info));
        words.add(new Word(R.drawable.contemporain, R.string.museum_of_modern, R.string.museum_of_modern_info));
        words.add(new Word(R.drawable.tradition, R.string.museum_tradition, R.string.museum_tradition_info));
        words.add(new Word(R.drawable.modjahid, R.string.museum_modjahid, R.string.museum_modjahid_info));
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        WordAdapter adapter = new WordAdapter(getContext(), words);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
        });
        return rootView;
    }
}