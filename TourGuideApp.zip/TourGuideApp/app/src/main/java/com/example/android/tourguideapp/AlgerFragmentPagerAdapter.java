package com.example.android.tourguideapp;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class AlgerFragmentPagerAdapter extends FragmentPagerAdapter {
    /** Context of the app */
    final private Context mContext;

    public AlgerFragmentPagerAdapter(Context context, FragmentManager fmalger) {
        super(fmalger);
        mContext = context;
    }
    @NonNull
    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new HotelFragment();
        } else if (position == 1) {
            return new BeachFragment();
        } else if (position == 2) {
            return new MuseumsFragment();
        } else {
            return new ParkFragment();
        }
    }

    @Override
    public int getCount() {
        return 4;
    }
    /**
     * This method may be called by the ViewPager to obtain a title string
     * to describe the specified page. This method may return null
     * indicating no title for this page. The default implementation returns
     * null.
     *
     * @param position The position of the title requested
     * @return A title for the requested page
     */
    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return mContext.getString(R.string.category_hotel);
        } else if (position == 1) {
            return mContext.getString(R.string.category_beach);
        } else if (position == 2) {
            return mContext.getString(R.string.category_museums);
        } else {
            return mContext.getString(R.string.category_park);
        }
    }
}