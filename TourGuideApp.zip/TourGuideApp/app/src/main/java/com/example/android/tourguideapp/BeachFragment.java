package com.example.android.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class BeachFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final ArrayList<Word> words = new ArrayList<>();
        words.add(new Word(R.drawable.sidifaradj, R.string.beach_sidi_faradj, R.string.beach_sidi_faradj_info));
        words.add(new Word(R.drawable.azure, R.string.beach_azure, R.string.beach_azure_info));
        words.add(new Word(R.drawable.plagepalmbeach, R.string.beach_palm, R.string.beach_palm_info));
        words.add(new Word(R.drawable.sheratonstawali, R.string.beach_hotel_staoueli, R.string.beach_hotel_staoueli_info));
        words.add(new Word(R.drawable.kettani, R.string.beach_kettani, R.string.beach_kettani_info));
        View rootView = inflater.inflate(R.layout.word_list, container, false);
        WordAdapter adapter = new WordAdapter(getContext(), words);
        ListView listView = rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {

        });
        return rootView;
    }
}