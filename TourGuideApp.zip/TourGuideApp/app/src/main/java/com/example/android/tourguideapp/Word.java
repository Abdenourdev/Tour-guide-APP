package com.example.android.tourguideapp;

public class Word {
    private final int mImageResourceID;
    private final int mDefaultName;
    private final int mDefaultInformation;

    public Word(int resourceID, int defaultName, int defaultInformation) {
        mDefaultName = defaultName;
        mDefaultInformation = defaultInformation;
        mImageResourceID = resourceID;
    }

    public int getDefaulLocationName() {
        return mDefaultName;
    }

    public int getDefaulInformation() {
        return mDefaultInformation;
    }

    public int getImageResourceID() {
        return mImageResourceID;
    }
}
